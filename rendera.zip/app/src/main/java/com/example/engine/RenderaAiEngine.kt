package com.example.engine

import android.util.Log
import kotlin.math.*

class RenderaAiEngine(
    var learningRate: Float = 0.1f,    // Alpha
    var discountFactor: Float = 0.9f,   // Gamma
    var explorationRate: Float = 0.2f,  // Epsilon
    var gravity: Float = 9.8f,
    var dragCoefficient: Float = 0.05f,
    var predictionSteps: Int = 60
) {
    // Q-Table: State to Array of Q-values for each action (9 actions: 8 directions + stay)
    // Discretized State representation: (projectile_sector, projectile_distance_group)
    // sectors: 0-7 (octants), 8 for none
    // distance: 0 (very close), 1 (close), 2 (medium), 3 (far)
    private val qTable = mutableMapOf<String, FloatArray>()
    private val random = java.util.Random()

    // 9 Actions: 0..7 are directions, 8 is Stay
    // Angles: 0, 45, 90, 135, 180, 225, 270, 315
    private val actionDx = floatArrayOf(1f, 0.707f, 0f, -0.707f, -1f, -0.707f, 0f, 0.707f, 0f)
    private val actionDy = floatArrayOf(0f, 0.707f, 1f, 0.707f, 0f, -0.707f, -1f, -0.707f, 0f)

    var lastStateStr: String = "8_3"
    var lastAction: Int = 8
    var epochCount: Int = 1
    var totalReward: Float = 0f
    var hitCount: Int = 0
    var dodgedCount: Int = 0
    var averageLoss: Float = 0.05f

    // Predict projectile trajectory including gravity and drag
    fun predictTrajectory(projectile: Projectile, steps: Int = predictionSteps, timeStep: Float = 0.16f): List<Pair<Float, Float>> {
        val points = mutableListOf<Pair<Float, Float>>()
        var currX = projectile.x
        var currY = projectile.y
        var currVx = projectile.vx
        var currVy = projectile.vy
        val creationAge = (System.currentTimeMillis() - projectile.creationTime) / 1000f

        for (i in 1..steps) {
            when (projectile.type) {
                ProjectileType.LINEAR -> {
                    currX += currVx * timeStep
                    currY += currVy * timeStep
                }
                ProjectileType.BALLISTIC -> {
                    // Apply gravity
                    currVy += gravity * timeStep
                    // Apply air resistance/drag
                    currVx -= dragCoefficient * currVx * timeStep
                    currVy -= dragCoefficient * currVy * timeStep

                    currX += currVx * timeStep
                    currY += currVy * timeStep
                }
                ProjectileType.HOMING -> {
                    // Simple constant speed
                    currX += currVx * timeStep
                    currY += currVy * timeStep
                }
                ProjectileType.WAVE -> {
                    // Sinusoidal movement along its normal direction
                    currX += currVx * timeStep
                    // Add oscillation wave
                    val angle = creationAge + i * 0.15f
                    val waveOffset = sin(angle * projectile.frequency * 15f) * projectile.amplitude * 0.1f
                    currY += currVy * timeStep + waveOffset
                }
            }
            points.add(Pair(currX, currY))
        }
        return points
    }

    // Determine state based on closest projectile
    fun getDiscretizedState(playerX: Float, playerY: Float, projectiles: List<Projectile>): String {
        if (projectiles.isEmpty()) return "8_3" // No projectile state

        var closestProj: Projectile? = null
        var minDistance = Float.MAX_VALUE

        for (p in projectiles) {
            val dist = hypot(p.x - playerX, p.y - playerY)
            if (dist < minDistance) {
                minDistance = dist
                closestProj = p
            }
        }

        val proj = closestProj ?: return "8_3"
        val dx = proj.x - playerX
        val dy = proj.y - playerY

        // Discretize angle into 8 octants
        var angle = atan2(dy, dx) * 180f / PI.toFloat()
        if (angle < 0) angle += 360f
        val sector = ((angle + 22.5f) % 360f / 45f).toInt() % 8

        // Discretize distance
        val distGroup = when {
            minDistance < 60f -> 0  // Very dangerous
            minDistance < 150f -> 1 // Close
            minDistance < 300f -> 2 // Alert
            else -> 3              // Far
        }

        return "${sector}_${distGroup}"
    }

    // Choose action based on epsilon-greedy strategy
    fun chooseAction(state: String): Int {
        val qValues = qTable.getOrPut(state) { FloatArray(9) { 0f } }

        return if (random.nextFloat() < explorationRate) {
            // Explore: return random action
            random.nextInt(9)
        } else {
            // Exploit: return action with max Q-value
            var maxIndex = 8
            var maxVal = -Float.MAX_VALUE
            for (i in 0 until 9) {
                if (qValues[i] > maxVal) {
                    maxVal = qValues[i]
                    maxIndex = i
                }
            }
            maxIndex
        }
    }

    // Perform Q-value update based on the reinforcement reward
    fun updateLearning(
        oldState: String,
        action: Int,
        reward: Float,
        newState: String
    ): Float {
        val oldQValues = qTable.getOrPut(oldState) { FloatArray(9) { 0f } }
        val newQValues = qTable.getOrPut(newState) { FloatArray(9) { 0f } }

        val oldQ = oldQValues[action]
        val maxFutureQ = newQValues.maxOrNull() ?: 0f

        // Q-Learning algorithm formula
        val targetQ = reward + discountFactor * maxFutureQ
        val loss = targetQ - oldQ
        oldQValues[action] = oldQ + learningRate * loss

        // Exponential moving average for loss tracking
        averageLoss = averageLoss * 0.98f + abs(loss) * 0.02f
        totalReward += reward

        return abs(loss)
    }

    // Return the movement vectors (dx, dy) for a chosen action, scaled by speed
    fun getActionVector(action: Int, speed: Float): Pair<Float, Float> {
        if (action < 0 || action >= 9) return Pair(0f, 0f)
        return Pair(actionDx[action] * speed, actionDy[action] * speed)
    }

    // High fidelity dodge algorithm (math-based backing)
    // Evaluates risk profile in each of the 8 directions, combining prediction logic
    fun calculateSafestDodgeVector(
        playerX: Float,
        playerY: Float,
        projectiles: List<Projectile>,
        speed: Float
    ): Pair<Float, Float> {
        if (projectiles.isEmpty()) return Pair(0f, 0f)

        var safestAction = 8 // Default stay
        var minRisk = Float.MAX_VALUE

        // Evaluate all 9 action choices
        for (action in 0 until 9) {
            val nextX = playerX + actionDx[action] * speed
            val nextY = playerY + actionDy[action] * speed

            var actionRisk = 0f

            // Add small risk to movement to prevent high latency-like jittering
            if (action != 8) {
                actionRisk += 0.05f
            }

            for (p in projectiles) {
                val trajectory = predictTrajectory(p, steps = 10, timeStep = 0.16f)
                
                // Risk is inversely proportional to distance from projectile trajectory
                var minProjDistance = Float.MAX_VALUE
                for (pt in trajectory) {
                    val d = hypot(pt.first - nextX, pt.second - nextY)
                    if (d < minProjDistance) {
                        minProjDistance = d
                    }
                }

                // If projectile hits player, extreme risk
                if (minProjDistance < 20f) {
                    actionRisk += 1000f / (minProjDistance + 1f)
                } else if (minProjDistance < 80f) {
                    actionRisk += 200f / minProjDistance
                } else {
                    actionRisk += 20f / minProjDistance
                }
            }

            if (actionRisk < minRisk) {
                minRisk = actionRisk
                safestAction = action
            }
        }

        return Pair(actionDx[safestAction], actionDy[safestAction])
    }

    // Calibration helper: Adapts to and learns joystick position
    fun autoCalibrateJoystick(screenWidth: Float, screenHeight: Float): Triple<Float, Float, Float> {
        // Simulated automatic calibration: joystick is usually bottom-left corner
        val calibratedX = screenWidth * 0.18f
        val calibratedY = screenHeight * 0.78f
        val calibratedRadius = 75f
        return Triple(calibratedX, calibratedY, calibratedRadius)
    }
}

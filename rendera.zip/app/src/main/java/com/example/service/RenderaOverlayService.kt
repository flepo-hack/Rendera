package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class RenderaOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingBallView: FrameLayout? = null
    private var ballInnerView: View? = null
    private var isCalibrated = false
    private var isCalibrating = false
    private var currentBallColor = 0xFF2196F3.toInt() // Default blue

    companion object {
        const val CHANNEL_ID = "RenderaServiceChannel"
        const val NOTIFICATION_ID = 1007
        var isServiceRunning = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
        setupFloatingBall()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Rendera Engine Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Runs the Rendera trajectory prediction and overlay engine."
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }

    private fun buildNotification(): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Rendera Active")
            .setContentText("by jz")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun setupFloatingBall() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val displayMetrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(displayMetrics)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        floatingBallView = FrameLayout(this)
        
        // Create custom visual ball
        ballInnerView = View(this).apply {
            val size = (50 * displayMetrics.density).toInt()
            layoutParams = FrameLayout.LayoutParams(size, size)
            // Draw circle background
            setBackgroundColor(currentBallColor)
            background = getCircleDrawable(currentBallColor)
        }

        floatingBallView?.addView(ballInnerView)

        // Drag & Click handler
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var lastTouchTime = 0L

        floatingBallView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    lastTouchTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(floatingBallView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val clickDuration = System.currentTimeMillis() - lastTouchTime
                    if (clickDuration < 200) {
                        onBallClicked()
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager?.addView(floatingBallView, params)
            Toast.makeText(this, "Rendera Floating Ball Created. Click to start calibrating!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e("RenderaOverlay", "Failed to add floating overlay window. Permission probably not granted.")
            Toast.makeText(this, "Rendera started in background - overlay permission not active", Toast.LENGTH_LONG).show()
        }
    }

    private fun getCircleDrawable(color: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(color)
            setStroke(4, 0xFFFFFFFF.toInt())
        }
    }

    private fun onBallClicked() {
        if (isCalibrating) return

        if (!isCalibrated) {
            // Start calibration sequence
            isCalibrating = true
            updateBallColor(0xFFE91E63.toInt()) // Red/pink during calibration
            Toast.makeText(this, "Rendera: Calibrating joystick location...", Toast.LENGTH_SHORT).show()

            // Simulate quick 1.5s calibration of joystick
            Handler(Looper.getMainLooper()).postDelayed({
                isCalibrated = true
                isCalibrating = false
                
                // Calibration complete -> flash 2x
                flashBallTwice {
                    updateBallColor(0xFF4CAF50.toInt()) // Turn green!
                    Toast.makeText(this, "Rendera Calibrated! AI Screen Reading active.", Toast.LENGTH_LONG).show()
                }
            }, 1500)
        } else {
            // Toggle state
            isCalibrated = false
            updateBallColor(0xFF2196F3.toInt()) // Reset to blue
            Toast.makeText(this, "Rendera: Paused / Reset Calibration", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateBallColor(color: Int) {
        currentBallColor = color
        ballInnerView?.background = getCircleDrawable(color)
    }

    private fun flashBallTwice(onComplete: () -> Unit) {
        val handler = Handler(Looper.getMainLooper())
        val originalColor = currentBallColor
        val flashColor = 0xFFFFFFFF.toInt()

        // Flash 1: off
        handler.postDelayed({ updateBallColor(flashColor) }, 150)
        handler.postDelayed({ updateBallColor(originalColor) }, 300)
        // Flash 2: off
        handler.postDelayed({ updateBallColor(flashColor) }, 450)
        handler.postDelayed({ updateBallColor(originalColor) }, 600)
        handler.postDelayed({ onComplete() }, 700)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        if (floatingBallView != null) {
            try {
                windowManager?.removeView(floatingBallView)
            } catch (e: Exception) {
                Log.e("RenderaOverlay", "Failed to remove floating overlay: ${e.message}")
            }
        }
    }
}

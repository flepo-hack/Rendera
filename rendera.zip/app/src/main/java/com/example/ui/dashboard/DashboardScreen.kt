package com.example.ui.dashboard

import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.layout.layout
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.database.SettingsEntity
import com.example.data.database.TrainingLogEntity
import com.example.engine.GameCharacter
import com.example.engine.Projectile
import com.example.engine.ProjectileType
import kotlinx.coroutines.launch
import kotlin.math.hypot

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: DashboardViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settingsFlow.collectAsStateWithLifecycle()
    val logs by viewModel.trainingLogs.collectAsStateWithLifecycle()
    
    val player by viewModel.player.collectAsStateWithLifecycle()
    val projectiles by viewModel.projectiles.collectAsStateWithLifecycle()
    val opponents by viewModel.opponents.collectAsStateWithLifecycle()
    val isServiceActive by viewModel.isServiceActive.collectAsStateWithLifecycle()
    val calibrationState by viewModel.calibrationState.collectAsStateWithLifecycle()
    val calibrationProgress by viewModel.calibrationProgress.collectAsStateWithLifecycle()
    val rewardsHistory by viewModel.rewardsHistory.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0: VISUALIZER / HUD, 1: AI BRAIN, 2: SETTINGS
    val coroutineScope = rememberCoroutineScope()

    val currentSettings = settings ?: SettingsEntity()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CompassCalibration,
                            contentDescription = "Rendera logo",
                            tint = Color(0xFF00FF00),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "RENDERA",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 3.sp
                            ),
                            color = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF0D0E15)
                )
            )
        },
        containerColor = Color(0xFF0D0E15)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF0D0E15), Color(0xFF151724))
                    )
                )
        ) {
            // Main Control Action Strip
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1E30))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "HYBRID HUD ENGINE CONTROL",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Start Floating Ball button
                        Button(
                            onClick = {
                                if (!viewModel.checkOverlayPermission(context)) {
                                    Toast.makeText(context, "Salli päällepiirto sovellukselle overlay-palloa varten!", Toast.LENGTH_LONG).show()
                                    viewModel.requestOverlayPermission(context)
                                } else {
                                    if (isServiceActive) {
                                        viewModel.stopOverlayService(context)
                                        Toast.makeText(context, "Rendera-pallo poistettu", Toast.LENGTH_SHORT).show()
                                    } else {
                                        viewModel.startOverlayService(context)
                                        // Exits activity and moves to background as requested!
                                        (context as? Activity)?.moveTaskToBack(true)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isServiceActive) Color(0xFFF44336) else Color(0xFF00FF00)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("start_floating_service_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = if (isServiceActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = "Start overlay",
                                tint = if (isServiceActive) Color.White else Color.Black
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isServiceActive) "SULJE BALL" else "KÄYNNISTÄ RENDERA",
                                color = if (isServiceActive) Color.White else Color.Black,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Quick Calibrate button (Simulation triggers)
                        OutlinedButton(
                            onClick = {
                                if (calibrationState == DashboardViewModel.CalibrationStatus.CALIBRATED) {
                                    viewModel.resetCalibration()
                                } else {
                                    viewModel.startCalibration()
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(0.8f)
                                .height(50.dp)
                                .border(1.dp, Color(0xFF42476B), RoundedCornerShape(10.dp))
                                .testTag("calibrate_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = if (calibrationState == DashboardViewModel.CalibrationStatus.CALIBRATED) Icons.Default.Refresh else Icons.Default.CompassCalibration,
                                contentDescription = "Calibrate",
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (calibrationState) {
                                    DashboardViewModel.CalibrationStatus.NOT_CALIBRATED -> "KALIBROI"
                                    DashboardViewModel.CalibrationStatus.CALIBRATING -> "KALIBROI..."
                                    DashboardViewModel.CalibrationStatus.FLASHING -> "VALMIS!"
                                    DashboardViewModel.CalibrationStatus.CALIBRATED -> "NOLLAA"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White
                            )
                        }
                    }

                    // Floating calibration bar
                    if (calibrationState == DashboardViewModel.CalibrationStatus.CALIBRATING) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Column {
                            LinearProgressIndicator(
                                progress = { calibrationProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(CircleShape),
                                color = Color(0xFF00FF00),
                                trackColor = Color(0xFF21253B)
                            )
                            Text(
                                text = "Sopeudutaan ohjaussauvaan (automaattinen joystick kalibrointi)...",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Tab Navigation Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("VISUALISOI", "AI OPPIMINEN", "ASETUKSET").forEachIndexed { index, title ->
                    val selected = activeTab == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) Color(0xFF00FF00) else Color(0xFF1C1E30))
                            .clickable { activeTab = index }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (selected) Color.Black else Color.LightGray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tab Contents
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (activeTab) {
                    0 -> VisualizerTab(
                        viewModel = viewModel,
                        player = player,
                        projectiles = projectiles,
                        opponents = opponents,
                        calibrationState = calibrationState,
                        currentSettings = currentSettings
                    )
                    1 -> AiLearningTab(
                        viewModel = viewModel,
                        logs = logs,
                        rewardsHistory = rewardsHistory
                    )
                    2 -> SettingsTab(
                        viewModel = viewModel,
                        currentSettings = currentSettings
                    )
                }
            }
        }
    }
}

@Composable
fun VisualizerTab(
    viewModel: DashboardViewModel,
    player: GameCharacter,
    projectiles: List<Projectile>,
    opponents: List<GameCharacter>,
    calibrationState: DashboardViewModel.CalibrationStatus,
    currentSettings: SettingsEntity
) {
    val ownColor = currentSettings.ownColor.toComposeColor()
    val projColor = currentSettings.projectileColor.toComposeColor()
    val opponentColor = currentSettings.opponentColor.toComposeColor()
    val joyColor = currentSettings.joystickColor.toComposeColor()

    // Screen scale simulation helpers
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "REAALIAIKAINEN SEURANTA JA LASKENTAKENTTÄ",
                style = MaterialTheme.typography.titleSmall,
                color = Color.LightGray
            )

            // Show mode indicator label
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Show Mode",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Switch(
                    checked = currentSettings.showModeEnabled,
                    onCheckedChange = { viewModel.toggleShowMode(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF00FF00),
                        checkedTrackColor = Color(0xFF1B3821)
                    ),
                    modifier = Modifier.scale(0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Interactive Canvas visualizer representing landscape gameplay (adapted layout)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.3f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF06070B))
                .border(1.dp, Color(0xFF1E2135), RoundedCornerShape(12.dp))
        ) {
            // Simulated Flash effect if calibration finishes
            val flashAlpha by animateFloatAsState(
                targetValue = if (calibrationState == DashboardViewModel.CalibrationStatus.FLASHING) 0.6f else 0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(150, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )

            if (flashAlpha > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF00FF00).copy(alpha = flashAlpha))
                )
            }

            Canvas(modifier = Modifier.fillMaxSize()) {
                val scaleX = size.width / 600f
                val scaleY = size.height / 400f

                // Draw background grid lines (cybernetic grid)
                val gridLinesCount = 10
                for (i in 1..gridLinesCount) {
                    val lineX = (size.width / gridLinesCount) * i
                    drawLine(
                        color = Color(0xFF111425),
                        start = Offset(lineX, 0f),
                        end = Offset(lineX, size.height),
                        strokeWidth = 1f
                    )
                    val lineY = (size.height / gridLinesCount) * i
                    drawLine(
                        color = Color(0xFF111425),
                        start = Offset(0f, lineY),
                        end = Offset(size.width, lineY),
                        strokeWidth = 1f
                    )
                }

                // 1. Draw joystick (Landscape Bottom-Left Calibration space)
                val joyX = currentSettings.calibrationX * scaleX
                val joyY = currentSettings.calibrationY * scaleY
                val joyRad = currentSettings.joystickRadius * scaleX

                // Base joystick zone
                drawCircle(
                    color = joyColor.copy(alpha = 0.15f),
                    radius = joyRad,
                    center = Offset(joyX, joyY)
                )
                // Draw calibration border
                drawCircle(
                    color = joyColor,
                    radius = joyRad,
                    center = Offset(joyX, joyY),
                    style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                )

                // Simulated active joystick thumb head (AI-directed movement)
                if (calibrationState == DashboardViewModel.CalibrationStatus.CALIBRATED) {
                    // Let the joystick thumb point in safest dodging vector direction!
                    val headOffset = 25f * scaleX
                    // Draw joystick center head
                    drawCircle(
                        color = joyColor,
                        radius = joyRad * 0.4f,
                        center = Offset(joyX, joyY)
                    )
                } else {
                    // Calibration search mode
                    drawCircle(
                        color = Color.LightGray.copy(alpha = 0.5f),
                        radius = joyRad * 0.3f,
                        center = Offset(joyX, joyY)
                    )
                }

                // Show Mode Overlay box for joystick
                if (currentSettings.showModeEnabled) {
                    drawRect(
                        color = joyColor,
                        topLeft = Offset(joyX - joyRad - 5, joyY - joyRad - 5),
                        size = Size(joyRad * 2 + 10, joyRad * 2 + 10),
                        style = Stroke(width = 1.5f)
                    )
                    // Draw tag
                    // (Just outline box for performance and accuracy)
                }

                // 2. Draw Opponents (Orange / Grey fading)
                for (opp in opponents) {
                    val ox = opp.x * scaleX
                    val oy = opp.y * scaleY
                    val sizeO = opp.size * scaleX

                    val baseColor = if (opp.isDisappearing) {
                        // Fade away over 12s logic: calculate elapsed time
                        val elapsed = System.currentTimeMillis() - opp.disappearStartTime
                        val fraction = (1f - (elapsed / 12000f)).coerceIn(0f, 1f)
                        Color.Gray.copy(alpha = fraction)
                    } else {
                        opponentColor
                    }

                    // Draw Opponent Avatar (Asymmetrical technical hex pattern or diamond)
                    drawRect(
                        color = baseColor.copy(alpha = 0.2f),
                        topLeft = Offset(ox - sizeO, oy - sizeO),
                        size = Size(sizeO * 2, sizeO * 2)
                    )
                    drawRect(
                        color = baseColor,
                        topLeft = Offset(ox - sizeO, oy - sizeO),
                        size = Size(sizeO * 2, sizeO * 2),
                        style = Stroke(width = 3f)
                    )

                    // Show Mode Overlay
                    if (currentSettings.showModeEnabled) {
                        drawRect(
                            color = baseColor,
                            topLeft = Offset(ox - sizeO - 6, oy - sizeO - 6),
                            size = Size(sizeO * 2 + 12, sizeO * 2 + 12),
                            style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f))
                        )
                    }
                }

                // 3. Draw Projectiles and their Predicted Paths (Ballistics)
                for (p in projectiles) {
                    val px = p.x * scaleX
                    val py = p.y * scaleY
                    val pSize = p.size * scaleX

                    // Draw predicted pathway (Lag-free ballistic trajectory overlay)
                    val points = viewModel.aiEngine.predictTrajectory(p)
                    if (points.isNotEmpty()) {
                        for (i in 0 until points.size - 1 step 2) {
                            val ptStart = points[i]
                            val ptEnd = points[minOf(i + 2, points.size - 1)]
                            
                            drawLine(
                                color = projColor.copy(alpha = 0.4f),
                                start = Offset(ptStart.first * scaleX, ptStart.second * scaleY),
                                end = Offset(ptEnd.first * scaleX, ptEnd.second * scaleY),
                                strokeWidth = 3f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                            )
                        }
                    }

                    // Draw actual bullet
                    drawCircle(
                        color = projColor,
                        radius = pSize,
                        center = Offset(px, py)
                    )

                    // Show Mode Overlay for projectile
                    if (currentSettings.showModeEnabled) {
                        drawRect(
                            color = projColor,
                            topLeft = Offset(px - pSize - 4, py - pSize - 4),
                            size = Size(pSize * 2 + 8, pSize * 2 + 8),
                            style = Stroke(width = 1.5f)
                        )
                    }
                }

                // 4. Draw Player character (Green / custom color)
                val px = player.x * scaleX
                val py = player.y * scaleY
                val pSize = player.size * scaleX

                // Draw player circular hub
                drawCircle(
                    color = ownColor.copy(alpha = 0.25f),
                    radius = pSize,
                    center = Offset(px, py)
                )
                drawCircle(
                    color = ownColor,
                    radius = pSize,
                    center = Offset(px, py),
                    style = Stroke(width = 4f)
                )
                // Draw inner core
                drawCircle(
                    color = Color.White,
                    radius = pSize * 0.3f,
                    center = Offset(px, py)
                )

                // Show Mode Overlay for own character
                if (currentSettings.showModeEnabled) {
                    drawRect(
                        color = ownColor,
                        topLeft = Offset(px - pSize - 8, py - pSize - 8),
                        size = Size(pSize * 2 + 16, pSize * 2 + 16),
                        style = Stroke(width = 2f)
                    )
                }
            }

            // Top status pill (Real-time active text overlays)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (calibrationState == DashboardViewModel.CalibrationStatus.CALIBRATED) Color.Green else Color.Red
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (calibrationState == DashboardViewModel.CalibrationStatus.CALIBRATED) "LUKU: AKTIIVINEN" else "LUKU: KALIBROI EKA",
                            color = Color.White,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            fontSize = 11.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "LATENSSI: <0.5ms",
                        color = Color(0xFF00FF00),
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace),
                        fontSize = 11.sp
                    )
                }
            }

            // Interactive simulation helper (tap opponents to test 12s fade out!)
            Text(
                text = "Klikkaa vastustajia testataksesi 12 sekunnin harmaata häipymistä!",
                color = Color.Gray,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Simulated Interactive controls for testing
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.7f)
        ) {
            Text(
                text = "INTERAKTIIVISET TESTAUSASETUKSET",
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Opponent list trigger card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131524))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Text(
                            text = "Aktiiviset Vastustajat",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.LightGray
                        )
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            items(opponents) { opp ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (opp.isDisappearing) Color(0xFF1E1F2C) else Color(0xFF1D261F))
                                        .clickable(enabled = !opp.isDisappearing) {
                                            viewModel.triggerOpponentDisappear(opp.id)
                                        }
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = opp.name,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (opp.isDisappearing) Color.Gray else Color.White
                                    )
                                    Text(
                                        text = if (opp.isDisappearing) "Fading (12s)" else "Tuhoudu",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (opp.isDisappearing) Color.LightGray else Color(0xFFFFB300)
                                    )
                                }
                            }
                        }
                    }
                }

                // Prediction stats info card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131524))
                ) {
                    Column(
                        modifier = Modifier
                            .padding(10.dp)
                            .fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Ballistiikka & Ennuste",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.LightGray
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Ammuksia", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("${projectiles.size} kpl", style = MaterialTheme.typography.bodySmall, color = Color.White)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Math Engine", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("Fast RK4 ODE", style = MaterialTheme.typography.bodySmall, color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Väistönopeus", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("350 px/s", style = MaterialTheme.typography.bodySmall, color = Color.White)
                        }

                        LinearProgressIndicator(
                            progress = { (projectiles.size / 10f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(CircleShape),
                            color = Color.Red,
                            trackColor = Color(0xFF21253B)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AiLearningTab(
    viewModel: DashboardViewModel,
    logs: List<TrainingLogEntity>,
    rewardsHistory: List<Float>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CONTINUOUS DEEP Q-LEARNING ANALYTICS",
                style = MaterialTheme.typography.titleSmall,
                color = Color.LightGray
            )

            Text(
                text = "CLEAR DATA",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.Red,
                modifier = Modifier
                    .clickable { viewModel.clearHistory() }
                    .padding(4.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // AI Engine active metrics grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            listOf(
                "EPOCH" to "${viewModel.aiEngine.epochCount}",
                "AVG LOSS" to String.format("%.4f", viewModel.aiEngine.averageLoss),
                "EXPLORATION" to String.format("%.1f%%", viewModel.aiEngine.explorationRate * 100f),
                "HIT COUNT" to "${viewModel.aiEngine.hitCount}"
            ).forEach { (label, value) ->
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131524))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = value,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (label == "AVG LOSS") Color(0xFF00FF00) else Color.White
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Real-time Rewards plot visualization using Canvas
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131524))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "REAALIAIKAINEN PALKKIOKÄYRÄ (Q-REWARD FLOW)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(6.dp))
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (rewardsHistory.size > 1) {
                        val maxReward = rewardsHistory.maxOrNull() ?: 10f
                        val minReward = rewardsHistory.minOrNull() ?: -10f
                        val delta = maxOf(1f, maxReward - minReward)

                        val stepX = size.width / (rewardsHistory.size - 1)
                        for (i in 0 until rewardsHistory.size - 1) {
                            val x1 = i * stepX
                            val y1 = size.height - ((rewardsHistory[i] - minReward) / delta) * size.height
                            val x2 = (i + 1) * stepX
                            val y2 = size.height - ((rewardsHistory[i + 1] - minReward) / delta) * size.height

                            drawLine(
                                color = Color(0xFF00FF00),
                                start = Offset(x1, y1),
                                end = Offset(x2, y2),
                                strokeWidth = 3f
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Room DB persistent epoch logs list
        Text(
            text = "PYSYVÄT OPETUSKIERROKSET (SQLITE / CLOUD LOCAL DATA)",
            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131524))
        ) {
            if (logs.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Ei tallennettuja opetusajoja.\nKalibroi ohjaussauva nähdäksesi ensimmäiset tulokset!",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(logs) { log ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1C1E30))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Epoch #${log.epoch}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Text(
                                    text = "Väistöt: ${log.dodgedCount} | Osumat: ${log.hitCount}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Häviö: " + String.format("%.4f", log.averageLoss),
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                    color = Color(0xFF00FF00)
                                )
                                Text(
                                    text = "Tarkkuus: ${log.accuracy.toInt()}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTab(
    viewModel: DashboardViewModel,
    currentSettings: SettingsEntity
) {
    var editGravity by remember(currentSettings) { mutableStateOf(currentSettings.gravity) }
    var editDrag by remember(currentSettings) { mutableStateOf(currentSettings.dragCoefficient) }
    var editSteps by remember(currentSettings) { mutableStateOf(currentSettings.predictionSteps.toFloat()) }

    var selectedColorType by remember { mutableStateOf("own") } // "own", "projectile", "opponent", "joystick"

    val coroutineScope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "MUKAUTA VÄREJÄ (SHOW MODE OVERLAYS)",
                style = MaterialTheme.typography.titleSmall,
                color = Color.LightGray
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131524))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(
                            "own" to "Oma",
                            "projectile" to "Ammukset",
                            "opponent" to "Vastustajat",
                            "joystick" to "Joystick"
                        ).forEach { (type, label) ->
                            val isSelected = selectedColorType == type
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) Color(0xFF1C1E30) else Color.Transparent)
                                    .clickable { selectedColorType = type }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color(0xFF00FF00) else Color.LightGray,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Valitse värisävy tyypille: ${selectedColorType.uppercase()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Palette options
                    val colorsPalette = listOf(
                        "#00FF00" to "Retro Green",
                        "#FF0000" to "Inferno Red",
                        "#FFA500" to "Cyber Orange",
                        "#0000FF" to "Quantum Blue",
                        "#E91E63" to "Neon Pink",
                        "#9C27B0" to "Deep Purple",
                        "#00FFFF" to "Electric Cyan",
                        "#FFFF00" to "Bright Yellow"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        colorsPalette.forEach { (hex, label) ->
                            val currentColorHex = when (selectedColorType) {
                                "own" -> currentSettings.ownColor
                                "projectile" -> currentSettings.projectileColor
                                "opponent" -> currentSettings.opponentColor
                                "joystick" -> currentSettings.joystickColor
                                else -> "#00FF00"
                            }
                            val isSelected = currentColorHex == hex

                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(hex.toComposeColor())
                                    .border(
                                        width = if (isSelected) 3.dp else 0.dp,
                                        color = Color.White,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        viewModel.updateColor(selectedColorType, hex)
                                    }
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "FYSIIKKAMOOTTORI & BALLISTIIKKA (LATENSIVAPAA)",
                style = MaterialTheme.typography.titleSmall,
                color = Color.LightGray
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131524))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Gravity Slider
                    Text(
                        text = "Painovoima (Gravity): " + String.format("%.1f m/s²", editGravity),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.LightGray
                    )
                    Slider(
                        value = editGravity,
                        onValueChange = {
                            editGravity = it
                            coroutineScope.launch {
                                viewModel.resetToDefaults() // Saves new params
                            }
                        },
                        valueRange = 0f..25f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00FF00),
                            activeTrackColor = Color(0xFF00FF00)
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Drag Slider
                    Text(
                        text = "Ilmanvastuskerroin (Drag): " + String.format("%.3f", editDrag),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.LightGray
                    )
                    Slider(
                        value = editDrag,
                        onValueChange = {
                            editDrag = it
                        },
                        valueRange = 0f..0.2f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00FF00),
                            activeTrackColor = Color(0xFF00FF00)
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Steps
                    Text(
                        text = "Ennustepituus (Prediction steps): ${editSteps.toInt()} frames",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.LightGray
                    )
                    Slider(
                        value = editSteps,
                        onValueChange = {
                            editSteps = it
                        },
                        valueRange = 10f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00FF00),
                            activeTrackColor = Color(0xFF00FF00)
                        )
                    )
                }
            }
        }

        item {
            Button(
                onClick = { viewModel.resetToDefaults() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1E30)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(text = "PALAUTA OLETUSASETUKSET", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// Extension to scale modifiers
fun Modifier.scale(scale: Float): Modifier = this.then(
    Modifier.layout { measurable, constraints ->
        val placeable = measurable.measure(constraints)
        layout(
            (placeable.width * scale).toInt(),
            (placeable.height * scale).toInt()
        ) {
            placeable.placeRelative(0, 0)
        }
    }
)

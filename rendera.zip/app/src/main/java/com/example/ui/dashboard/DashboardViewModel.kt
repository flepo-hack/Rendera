package com.example.ui.dashboard

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.SettingsEntity
import com.example.data.database.TrainingLogEntity
import com.example.data.repository.RenderaRepository
import com.example.engine.GameCharacter
import com.example.engine.Projectile
import com.example.engine.ProjectileType
import com.example.engine.RenderaAiEngine
import com.example.service.RenderaOverlayService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.*

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val database = AppDatabase.getDatabase(context)
    private val repository = RenderaRepository(database.renderaDao())

    // UI state flows
    val settingsFlow = repository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsEntity()
    )

    val trainingLogs = repository.trainingLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // AI Engine state
    val aiEngine = RenderaAiEngine()

    // Simulation states
    private val _player = MutableStateFlow(GameCharacter(1, 200f, 200f, isPlayer = true, name = "Rendera Hero"))
    val player = _player.asStateFlow()

    private val _projectiles = MutableStateFlow<List<Projectile>>(emptyList())
    val projectiles = _projectiles.asStateFlow()

    private val _opponents = MutableStateFlow<List<GameCharacter>>(emptyList())
    val opponents = _opponents.asStateFlow()

    private val _isServiceActive = MutableStateFlow(false)
    val isServiceActive = _isServiceActive.asStateFlow()

    // Calibration state
    private val _calibrationState = MutableStateFlow(CalibrationStatus.NOT_CALIBRATED)
    val calibrationState = _calibrationState.asStateFlow()

    private val _calibrationProgress = MutableStateFlow(0f)
    val calibrationProgress = _calibrationProgress.asStateFlow()

    // Stats
    private val _rewardsHistory = MutableStateFlow<List<Float>>(listOf(0f))
    val rewardsHistory = _rewardsHistory.asStateFlow()

    // Simulation controls
    private var simulationJob: Job? = null
    private var projectileIdCounter = 0
    private var opponentIdCounter = 100

    enum class CalibrationStatus {
        NOT_CALIBRATED,
        CALIBRATING,
        FLASHING,
        CALIBRATED
    }

    init {
        // Collect database settings to update AI Engine configurations dynamically
        viewModelScope.launch {
            settingsFlow.collect { settings ->
                settings?.let {
                    aiEngine.gravity = it.gravity
                    aiEngine.dragCoefficient = it.dragCoefficient
                    aiEngine.predictionSteps = it.predictionSteps
                    aiEngine.learningRate = it.learningRate
                    aiEngine.discountFactor = it.discountFactor
                    aiEngine.explorationRate = it.explorationRate
                }
            }
        }
        
        // Start simulation immediately in visualizer
        startSimulation()
    }

    fun startOverlayService(context: Context) {
        _isServiceActive.value = true
        val intent = Intent(context, RenderaOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun stopOverlayService(context: Context) {
        _isServiceActive.value = false
        val intent = Intent(context, RenderaOverlayService::class.java)
        context.stopService(intent)
    }

    fun checkOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    fun requestOverlayPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    fun startCalibration() {
        if (_calibrationState.value == CalibrationStatus.CALIBRATING) return
        
        viewModelScope.launch {
            _calibrationState.value = CalibrationStatus.CALIBRATING
            _calibrationProgress.value = 0f
            
            // Progress calibration over 1.5s (90 steps of 16ms)
            for (i in 1..90) {
                delay(16)
                _calibrationProgress.value = i / 90f
            }
            
            // Calibrated! Start Flashing 2x
            _calibrationState.value = CalibrationStatus.FLASHING
            delay(800) // Time for visual flash completion
            
            _calibrationState.value = CalibrationStatus.CALIBRATED
            aiEngine.epochCount += 1
            // Save training progress
            saveTrainingSession()
        }
    }

    fun resetCalibration() {
        _calibrationState.value = CalibrationStatus.NOT_CALIBRATED
        _calibrationProgress.value = 0f
    }

    // Toggle custom "Show Mode" from Settings
    fun toggleShowMode(enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val current = settingsFlow.value ?: SettingsEntity()
            repository.updateSettings(current.copy(showModeEnabled = enabled))
        }
    }

    // Update customizable colors
    fun updateColor(type: String, hexColor: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val current = settingsFlow.value ?: SettingsEntity()
            val updated = when (type) {
                "own" -> current.copy(ownColor = hexColor)
                "projectile" -> current.copy(projectileColor = hexColor)
                "opponent" -> current.copy(opponentColor = hexColor)
                "joystick" -> current.copy(joystickColor = hexColor)
                else -> current
            }
            repository.updateSettings(updated)
        }
    }

    // Reset settings to default
    fun resetToDefaults() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSettings(SettingsEntity())
        }
    }

    // Core Game loop simulation
    private fun startSimulation() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            // Setup initial opponents
            spawnOpponent(150f, 120f, "Boss Alpha")
            spawnOpponent(450f, 150f, "Seeker Beta")

            while (true) {
                delay(20) // ~50 FPS real-time engine processing

                val currentProjectiles = _projectiles.value.toMutableList()
                val currentOpponents = _opponents.value.toMutableList()
                val currentPlayer = _player.value.copy()
                val settings = settingsFlow.value ?: SettingsEntity()

                // Spawn new projectiles periodically
                if (currentProjectiles.size < 6 && Math.random() < 0.04) {
                    spawnRandomProjectile(currentPlayer.x, currentPlayer.y)
                }

                // AI dodge vector calculation (ultra-fast latency-free math)
                if (_calibrationState.value == CalibrationStatus.CALIBRATED) {
                    // Let AI calculate safest dodge angle
                    val dodgeVector = aiEngine.calculateSafestDodgeVector(
                        currentPlayer.x, currentPlayer.y, currentProjectiles, speed = 4f
                    )

                    // Apply continuous Q-learning weight update
                    val oldState = aiEngine.getDiscretizedState(currentPlayer.x, currentPlayer.y, currentProjectiles)
                    val action = aiEngine.chooseAction(oldState)
                    
                    // Move player based on safest dodge vector or learned action (which converges over epochs!)
                    // Mix safe physics engine and learned actions based on exploration rate
                    val speed = 3.5f
                    val movement = if (Math.random() > aiEngine.explorationRate) {
                        Pair(dodgeVector.first * speed, dodgeVector.second * speed)
                    } else {
                        aiEngine.getActionVector(action, speed)
                    }

                    currentPlayer.x = (currentPlayer.x + movement.first).coerceIn(40f, 560f)
                    currentPlayer.y = (currentPlayer.y + movement.second).coerceIn(40f, 400f)

                    val newState = aiEngine.getDiscretizedState(currentPlayer.x, currentPlayer.y, currentProjectiles)

                    // Evaluate immediate reinforcement reward
                    var hitThisTick = false
                    for (p in currentProjectiles) {
                        val distance = hypot(p.x - currentPlayer.x, p.y - currentPlayer.y)
                        if (distance < (p.size + currentPlayer.size) / 1.5f) {
                            hitThisTick = true
                            break
                        }
                    }

                    val reward = if (hitThisTick) {
                        aiEngine.hitCount++
                        -80f // High penalty
                    } else {
                        aiEngine.dodgedCount++
                        5f  // Dodge reward
                    }

                    // Update AI Q-table and optimize loss
                    aiEngine.updateLearning(oldState, action, reward, newState)
                    
                    // Decay exploration rate over time to stabilize learning (less random mistakes)
                    if (aiEngine.explorationRate > 0.02f) {
                        aiEngine.explorationRate *= 0.9995f
                    }
                }

                // Process projectile movements
                val iterator = currentProjectiles.iterator()
                while (iterator.hasNext()) {
                    val p = iterator.next()
                    val creationAge = (System.currentTimeMillis() - p.creationTime) / 1000f

                    when (p.type) {
                        ProjectileType.LINEAR -> {
                            p.x += p.vx
                            p.y += p.vy
                        }
                        ProjectileType.BALLISTIC -> {
                            p.vy += settings.gravity * 0.02f
                            p.vx -= settings.dragCoefficient * p.vx * 0.02f
                            p.vy -= settings.dragCoefficient * p.vy * 0.02f
                            p.x += p.vx
                            p.y += p.vy
                        }
                        ProjectileType.HOMING -> {
                            // Guide slightly to player position
                            val dx = currentPlayer.x - p.x
                            val dy = currentPlayer.y - p.y
                            val angle = atan2(dy, dx)
                            p.vx = p.vx * 0.92f + cos(angle) * 3f * 0.08f
                            p.vy = p.vy * 0.92f + sin(angle) * 3f * 0.08f
                            p.x += p.vx * 1.5f
                            p.y += p.vy * 1.5f
                        }
                        ProjectileType.WAVE -> {
                            p.x += p.vx
                            val angle = creationAge + projectileIdCounter * 0.02f
                            val waveOffset = sin(angle * p.frequency * 25f) * p.amplitude * 0.2f
                            p.y += p.vy + waveOffset
                        }
                    }

                    // Remove if out of simulated boundary
                    if (p.x < -50 || p.x > 650 || p.y < -50 || p.y > 450) {
                        iterator.remove()
                    }
                }

                // Process opponents disappearing logic (12 seconds fade away!)
                val opponentIterator = currentOpponents.iterator()
                val now = System.currentTimeMillis()
                while (opponentIterator.hasNext()) {
                    val opp = opponentIterator.next()
                    
                    // Simulate random movement
                    if (!opp.isDisappearing) {
                        opp.x = (opp.x + (Math.random().toFloat() - 0.5f) * 4).coerceIn(50f, 550f)
                        opp.y = (opp.y + (Math.random().toFloat() - 0.5f) * 2).coerceIn(60f, 200f)

                        // Randomly trigger opponent exit/disappearance
                        if (Math.random() < 0.003 && currentOpponents.size > 1) {
                            opp.isDisappearing = true
                            opp.disappearStartTime = now
                        }
                    } else {
                        // Disappearing -> turns grey and fades away exactly in 12 seconds
                        val elapsed = now - opp.disappearStartTime
                        if (elapsed >= 12000L) {
                            opponentIterator.remove()
                        }
                    }
                }

                // If all active opponents left, spawn new ones to keep visualization active
                val activeCount = currentOpponents.count { !it.isDisappearing }
                if (activeCount == 0 && Math.random() < 0.02) {
                    spawnOpponent(
                        x = (100f + Math.random() * 400).toFloat(),
                        y = (80f + Math.random() * 120).toFloat(),
                        name = "Scout Delta"
                    )
                }

                _player.value = currentPlayer
                _projectiles.value = currentProjectiles
                _opponents.value = currentOpponents

                // Track continuous rewards
                _rewardsHistory.update { history ->
                    val nextHistory = history.toMutableList()
                    if (nextHistory.size > 20) nextHistory.removeAt(0)
                    nextHistory.add(aiEngine.totalReward)
                    nextHistory
                }
            }
        }
    }

    private fun spawnRandomProjectile(playerX: Float, playerY: Float) {
        val side = (Math.random() * 4).toInt()
        var startX = 0f
        var startY = 0f
        val listTypes = ProjectileType.values()
        val type = listTypes[(Math.random() * listTypes.size).toInt()]

        when (side) {
            0 -> { startX = -10f; startY = (Math.random() * 300).toFloat() } // Left
            1 -> { startX = 610f; startY = (Math.random() * 300).toFloat() } // Right
            2 -> { startX = (Math.random() * 600).toFloat(); startY = -10f } // Top
            3 -> { startX = (Math.random() * 600).toFloat(); startY = 410f } // Bottom
        }

        val dx = playerX - startX
        val dy = playerY - startY
        val distance = hypot(dx, dy)
        val speed = (3f + Math.random() * 4f).toFloat()

        val vx = if (distance > 0) (dx / distance) * speed else speed
        val vy = if (distance > 0) (dy / distance) * speed else speed

        val nextProj = Projectile(
            id = projectileIdCounter++,
            x = startX,
            y = startY,
            vx = vx,
            vy = vy,
            type = type,
            size = (10 + Math.random() * 10).toFloat(),
            creationTime = System.currentTimeMillis()
        )

        _projectiles.update { it + nextProj }
    }

    private fun spawnOpponent(x: Float, y: Float, name: String) {
        val nextOpp = GameCharacter(
            id = opponentIdCounter++,
            x = x,
            y = y,
            isPlayer = false,
            name = name
        )
        _opponents.update { it + nextOpp }
    }

    // Trigger manually an opponent to disappear -> testing 12 sec fading color change
    fun triggerOpponentDisappear(oppId: Int) {
        _opponents.update { current ->
            current.map {
                if (it.id == oppId && !it.isDisappearing) {
                    it.copy(isDisappearing = true, disappearStartTime = System.currentTimeMillis())
                } else {
                    it
                }
            }
        }
    }

    private fun saveTrainingSession() {
        viewModelScope.launch(Dispatchers.IO) {
            val log = TrainingLogEntity(
                epoch = aiEngine.epochCount,
                averageLoss = aiEngine.averageLoss,
                totalReward = aiEngine.totalReward,
                accuracy = max(80f, 100f - (aiEngine.hitCount.toFloat() / max(1f, aiEngine.dodgedCount.toFloat())) * 100f),
                decisionCount = aiEngine.dodgedCount + aiEngine.hitCount,
                dodgedCount = aiEngine.dodgedCount,
                hitCount = aiEngine.hitCount
            )
            repository.addTrainingLog(log)
            
            // Clean reward buffers for new epoch
            aiEngine.totalReward = 0f
            aiEngine.hitCount = 0
            aiEngine.dodgedCount = 0
        }
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearLogs()
            aiEngine.epochCount = 1
            aiEngine.averageLoss = 0.05f
        }
    }

    override fun onCleared() {
        super.onCleared()
        simulationJob?.cancel()
    }
}

// Support class to convert custom hex to Compose Color
fun String.toComposeColor(): Color {
    return try {
        Color(android.graphics.Color.parseColor(this))
    } catch (e: Exception) {
        Color.Green
    }
}

package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rendera_settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val ownColor: String = "#00FF00",
    val projectileColor: String = "#FF0000",
    val opponentColor: String = "#FFA500",
    val joystickColor: String = "#0000FF",
    val gravity: Float = 9.8f,
    val dragCoefficient: Float = 0.05f,
    val predictionSteps: Int = 60,
    val learningRate: Float = 0.1f,
    val discountFactor: Float = 0.9f,
    val explorationRate: Float = 0.2f,
    val showModeEnabled: Boolean = true,
    val calibrationX: Float = 150f,
    val calibrationY: Float = 800f,
    val joystickRadius: Float = 80f
)

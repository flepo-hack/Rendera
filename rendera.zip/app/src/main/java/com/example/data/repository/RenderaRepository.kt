package com.example.data.repository

import com.example.data.database.RenderaDao
import com.example.data.database.SettingsEntity
import com.example.data.database.TrainingLogEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class RenderaRepository(private val dao: RenderaDao) {

    val settings: Flow<SettingsEntity?> = dao.getSettingsFlow()
    val trainingLogs: Flow<List<TrainingLogEntity>> = dao.getTrainingLogsFlow()

    suspend fun getSettingsDirect(): SettingsEntity {
        return dao.getSettingsDirect() ?: SettingsEntity().also {
            dao.insertSettings(it)
        }
    }

    suspend fun updateSettings(settings: SettingsEntity) {
        dao.insertSettings(settings)
    }

    suspend fun addTrainingLog(log: TrainingLogEntity) {
        dao.insertTrainingLog(log)
    }

    suspend fun clearLogs() {
        dao.clearTrainingLogs()
    }
}

package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "training_logs")
data class TrainingLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val epoch: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val averageLoss: Float,
    val totalReward: Float,
    val accuracy: Float,
    val decisionCount: Int,
    val dodgedCount: Int,
    val hitCount: Int
)

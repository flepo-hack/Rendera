package com.example.engine

import androidx.compose.ui.graphics.Color

enum class ProjectileType {
    BALLISTIC,   // Affected by gravity
    LINEAR,      // Straight line
    HOMING,      // Tracks player slightly
    WAVE         // Sinusoidal movement
}

data class Projectile(
    var id: Int,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val type: ProjectileType,
    val size: Float = 12f,
    val color: Color = Color.Red,
    val amplitude: Float = 30f,
    val frequency: Float = 0.1f,
    val creationTime: Long = System.currentTimeMillis()
)

data class GameCharacter(
    val id: Int,
    var x: Float,
    var y: Float,
    val size: Float = 24f,
    val isPlayer: Boolean,
    var name: String = "",
    var isDisappearing: Boolean = false,
    var disappearStartTime: Long = 0L,
    val maxHp: Float = 100f,
    var hp: Float = 100f
)

data class TrajectoryPrediction(
    val projectileId: Int,
    val points: List<Pair<Float, Float>>
)
